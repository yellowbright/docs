#!/bin/bash
/etc/init.d/ssh start
/usr/local/php/sbin/php-fpm -F

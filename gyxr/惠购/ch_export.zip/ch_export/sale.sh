./exportPartition.py FactSaleLogs toYYYYMM\(ordered_at\) 202001 
./exportPartition.py FactSaleLogs toYYYYMM\(ordered_at\) 202002
./exportPartition.py FactSaleLogs toYYYYMM\(ordered_at\) 202003

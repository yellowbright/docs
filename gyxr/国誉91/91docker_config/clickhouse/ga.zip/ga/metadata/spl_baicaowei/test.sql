ATTACH TABLE test
(
    `id` Int8
)
ENGINE = StripeLog()

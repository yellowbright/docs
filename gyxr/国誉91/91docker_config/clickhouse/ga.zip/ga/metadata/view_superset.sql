ATTACH DATABASE view_superset
ENGINE = Ordinary

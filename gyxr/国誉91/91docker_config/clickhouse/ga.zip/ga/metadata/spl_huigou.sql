ATTACH DATABASE spl_huigou
ENGINE = Ordinary

ATTACH DATABASE vview_huigou
ENGINE = Ordinary

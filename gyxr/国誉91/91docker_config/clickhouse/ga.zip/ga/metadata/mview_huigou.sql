ATTACH DATABASE mview_huigou
ENGINE = Ordinary

ATTACH TABLE hejialiang
(
    `id` Int16, 
    `name` String
)
ENGINE = StripeLog()

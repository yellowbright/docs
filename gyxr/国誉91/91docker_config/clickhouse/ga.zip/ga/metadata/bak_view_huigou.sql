ATTACH DATABASE bak_view_huigou
ENGINE = Ordinary

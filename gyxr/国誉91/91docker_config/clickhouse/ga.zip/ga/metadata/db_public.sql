ATTACH DATABASE db_public
ENGINE = Ordinary

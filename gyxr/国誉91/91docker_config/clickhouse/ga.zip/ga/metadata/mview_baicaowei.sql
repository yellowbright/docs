ATTACH DATABASE mview_baicaowei
ENGINE = Ordinary

ATTACH DATABASE vview_baicaowei
ENGINE = Ordinary

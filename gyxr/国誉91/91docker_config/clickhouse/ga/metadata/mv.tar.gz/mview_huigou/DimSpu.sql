ATTACH TABLE DimSpu
(
    `spu` Nullable(String), 
    `id` Int64, 
    `SPUKey` Int64, 
    `spu名称` Nullable(String), 
    `cat1` Nullable(String), 
    `cat2` Nullable(String), 
    `cat3` Nullable(String), 
    `cat4` Nullable(String), 
    `cat5` Nullable(String), 
    `supply_cycle` Nullable(Int64), 
    `min_order_count` Nullable(Float32), 
    `大类` Nullable(String), 
    `中类` Nullable(String), 
    `小类` Nullable(String), 
    `小小类` Nullable(String), 
    `子类` Nullable(String), 
    `吊牌价` Nullable(Float32), 
    `产品年` Nullable(Int64), 
    `产品季` Nullable(String), 
    `产品年季` Nullable(String), 
    `season_start_date` Nullable(Date), 
    `season_end_date` Nullable(Date)
)
ENGINE = StripeLog

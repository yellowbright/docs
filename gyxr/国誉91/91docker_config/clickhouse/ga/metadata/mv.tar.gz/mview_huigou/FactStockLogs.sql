ATTACH TABLE FactStockLogs
(
    `id` UInt64, 
    `DateKey` UInt32, 
    `store_date` Date, 
    `storehouse_code` String, 
    `SKUKey` UInt64, 
    `stock_qty` Nullable(Float32), 
    `on_road_qty` Nullable(Float32), 
    `order_qty` Nullable(Float32)
)
ENGINE = MergeTree()
PARTITION BY toYYYYMM(store_date)
ORDER BY store_date
SETTINGS index_granularity = 8192
